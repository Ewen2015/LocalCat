#!/bin/bash

cd ~/.ssh
ssh-keygen
cat id_rsa.pub